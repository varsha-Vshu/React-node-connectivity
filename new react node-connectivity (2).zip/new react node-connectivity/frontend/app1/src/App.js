import React ,{useState,useEffect} from 'react'

 function App() {
  const[backendData,setData]=useState([{}]);
  useEffect(()=>{
    fetch('/api').then(response => response.json()).then(d=>setData(d));
  },[]);
  return (
    <div>
     {(typeof backendData.user ==='undefined') ?(
      <p>undefined</p>
     ):(backendData.user.map((user,i)=>(
     <p key={i}>{user}</p>
     )))} 
    </div>
  )
  
}


export default App;
